@echo off
title Gym Me - Fitness Center Management
cd /d "%~dp0"
java -cp "build/classes;lib/mariadb-java-client-3.3.3.jar" gym.form.FormLogin
pause
